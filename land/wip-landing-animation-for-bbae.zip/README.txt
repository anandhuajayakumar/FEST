A Pen created at CodePen.io. You can find this one at http://codepen.io/idiotWu/pen/AXgbWy.

 Landing animation for https://a.bbae.com